module.exports = {
  images: {
    //   domains: ['assets.acme.com'],
    //   loader: 'imgix',
    // domains: ['ipfs.infura.io'],
    // loader: 'imgix', // from external image. not localhost
    // path: '', // not include ?URL=
    //  formats: ['image/webp'],
  },
  //trailingSlash: true // prevent page refresh on 404 page not working
}