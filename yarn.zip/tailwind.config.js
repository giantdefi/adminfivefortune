module.exports = {
  content: [
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        //  Rampart: ["Rampart", "sans-serif"],
        Poppins: ["Poppins", " sans-serif"],
        //  Bebas: ["Bebas", "sans-serif"],
        Roboto: ["Roboto", " sans-serif"],
        rocksalt: ["Rock Salt", "cursive"],
      },
    },
  },
  plugins: [],
}