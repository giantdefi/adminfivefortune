# admin app management for fivefortune
Implementation of NexJS, Tailwind, Redux Toolkit 

This app a fully responsive main page and users page for mobile and laptop screen


