"use strict";
exports.id = 249;
exports.ids = [249];
exports.modules = {

/***/ 8847:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports loaderSlice, resetLoader, setSpinner, setBtnSpinner, setBtnDisabled, setMenuSpinner */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    spinner: false,
    btnSpinner: false,
    btnDisabled: false,
    menuSpinner: false
};
const loaderSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "loader",
    initialState,
    reducers: {
        setSpinner: (state, action)=>{
            state.spinner = action.payload;
        },
        setBtnSpinner: (state, action)=>{
            state.btnSpinner = action.payload;
        },
        setBtnDisabled: (state, action)=>{
            state.btnDisabled = action.payload;
        },
        setMenuSpinner: (state, action)=>{
            state.menuSpinner = action.payload;
        },
        setLoader: (state, action)=>{
            state.loader = action.payload;
        },
        resetLoader: ()=>initialState
    }
});
const { resetLoader , setSpinner , setBtnSpinner , setBtnDisabled , setMenuSpinner ,  } = loaderSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (loaderSlice.reducer);


/***/ }),

/***/ 7861:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "qr": () => (/* binding */ setAllowSound)
/* harmony export */ });
/* unused harmony exports SettingSlice, resetSetting, setIsFlashOut, setMarketingPlanSelected, setSetting_level_1_username, setWalletCopyLink, setNewActivated_username */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    marketingPlanSelected: false,
    setting_level_1_username: false,
    newActivated_username: false,
    isFlashOut: false,
    showWalletCopyLink: true,
    allowSound: false
};
const SettingSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "setting",
    initialState,
    reducers: {
        setMarketingPlanSelected: (state, action)=>{
            state.marketingPlanSelected = action.payload;
        },
        setSetting_level_1_username: (state, action)=>{
            state.setting_level_1_username = action.payload;
        },
        setNewActivated_username: (state, action)=>{
            state.newActivated_username = action.payload;
        },
        setIsFlashOut: (state, action)=>{
            state.isFlashOut = action.payload;
        },
        setWalletCopyLink: (state, action)=>{
            state.showWalletCopyLink = action.payload;
        },
        setAllowSound: (state, action)=>{
            state.allowSound = action.payload;
        },
        resetSetting: ()=>initialState
    }
});
const { resetSetting , setAllowSound , setIsFlashOut , setMarketingPlanSelected , setSetting_level_1_username , setWalletCopyLink , setNewActivated_username  } = SettingSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SettingSlice.reducer);


/***/ })

};
;