"use strict";
exports.id = 17;
exports.ids = [17];
exports.modules = {

/***/ 2719:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$M": () => (/* binding */ setIsLogin),
/* harmony export */   "WA": () => (/* binding */ setIsActive),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "fc": () => (/* binding */ setSponsor),
/* harmony export */   "kH": () => (/* binding */ setWallet),
/* harmony export */   "nZ": () => (/* binding */ setIsAdmin),
/* harmony export */   "o4": () => (/* binding */ setToken),
/* harmony export */   "qC": () => (/* binding */ setName),
/* harmony export */   "vV": () => (/* binding */ setEmail),
/* harmony export */   "wt": () => (/* binding */ setLogout)
/* harmony export */ });
/* unused harmony exports AuthSlice, setAuthToken */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    isLogin: false,
    isActive: false,
    isAdmin: false,
    name: false,
    email: false,
    sponsor: false,
    token: false,
    wallet: false,
    authToken: false
};
const AuthSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "auth",
    initialState,
    reducers: {
        setIsLogin: (state, action)=>{
            state.isLogin = action.payload;
        },
        setIsActive: (state, action)=>{
            state.isActive = action.payload;
        },
        setIsAdmin: (state, action)=>{
            state.isAdmin = action.payload;
        },
        setName: (state, action)=>{
            state.name = action.payload;
        },
        setEmail: (state, action)=>{
            state.email = action.payload;
        },
        setToken: (state, action)=>{
            state.token = action.payload;
        },
        setSponsor: (state, action)=>{
            state.sponsor = action.payload;
        },
        setWallet: (state, action)=>{
            state.wallet = action.payload;
        },
        setAuthToken: (state, action)=>{
            state.authToken = action.payload;
        },
        setLogout: ()=>initialState
    }
});
const { setLogout , setIsLogin , setName , setIsActive , setIsAdmin , setToken , setWallet , setSponsor , setAuthToken , setEmail  } = AuthSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthSlice.reducer);


/***/ }),

/***/ 915:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fx": () => (/* binding */ resetForm),
/* harmony export */   "Wf": () => (/* binding */ setFormSponsor),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports FormSlice, setFormName, setFormUsername, setFormPhone, setFormPassword, setFormConfirmPassword, setFormEmail, setConfirmPassword, setCountry, setCurrentpassword, setNewPassword, setNewPasswordConfirm, setFirstName, setLastName */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    // registration form
    sponsor: false,
    name: false,
    username: false,
    email: false,
    phone: false,
    password: false,
    confirmPassword: false,
    country: false,
    firstName: false,
    lastName: false,
    //forgot pass
    // WD
    wdWalletAmount: false,
    walletAddr: false,
    //---wd wallet
    depositAmount: false,
    admWalletAddress: false,
    transactionHash: false,
    userWalletAddr: false,
    setSearchUsername: false,
    // change password
    currentpassword: false,
    newPassword: false,
    newPasswordConfirm: false
};
const FormSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "form",
    initialState,
    reducers: {
        setFormSponsor: (state, action)=>{
            state.sponsor = action.payload;
        },
        setFormName: (state, action)=>{
            state.name = action.payload;
        },
        setFormUsername: (state, action)=>{
            state.username = action.payload;
        },
        setFirstName: (state, action)=>{
            state.firstName = action.payload;
        },
        setLastName: (state, action)=>{
            state.lastName = action.payload;
        },
        setFormPhone: (state, action)=>{
            state.phone = action.payload;
        },
        setFormEmail: (state, action)=>{
            state.email = action.payload;
        },
        setFormPassword: (state, action)=>{
            state.password = action.payload;
        },
        setFormConfirmPassword: (state, action)=>{
            state.confirmPassword = action.payload;
        },
        setCountry: (state, action)=>{
            state.country = action.payload;
        },
        // change password
        setCurrentpassword: (state, action)=>{
            state.currentpassword = action.payload;
        },
        setNewPassword: (state, action)=>{
            state.newPassword = action.payload;
        },
        setNewPasswordConfirm: (state, action)=>{
            state.newPasswordConfirm = action.payload;
        },
        resetForm: ()=>initialState
    }
});
const { resetForm , setFormSponsor , setFormName , setFormUsername , setFormPhone , setFormPassword , setFormConfirmPassword , setFormEmail , setConfirmPassword , setCountry , setCurrentpassword , setNewPassword , setNewPasswordConfirm , setFirstName , setLastName  } = FormSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormSlice.reducer);


/***/ })

};
;