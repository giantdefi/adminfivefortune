"use strict";
exports.id = 809;
exports.ids = [809];
exports.modules = {

/***/ 7809:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Aq": () => (/* binding */ setUsers_stats),
/* harmony export */   "Gw": () => (/* binding */ setActive_users),
/* harmony export */   "Nk": () => (/* binding */ setTotal_paid),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "hC": () => (/* binding */ setTotal_wd),
/* harmony export */   "rY": () => (/* binding */ setTotal_users),
/* harmony export */   "wX": () => (/* binding */ setAllowReloadStats)
/* harmony export */ });
/* unused harmony export StatstSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    total_users: false,
    active_users: false,
    total_wd: false,
    total_paid: false,
    users_stats: false,
    allowReloadStats: false
};
const StatstSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "stats",
    initialState,
    reducers: {
        setTotal_users: (state, action)=>{
            state.total_users = action.payload;
        },
        setActive_users: (state, action)=>{
            state.active_users = action.payload;
        },
        setTotal_wd: (state, action)=>{
            state.total_wd = action.payload;
        },
        setTotal_paid: (state, action)=>{
            state.total_paid = action.payload;
        },
        setUsers_stats: (state, action)=>{
            state.users_stats = action.payload;
        },
        setAllowReloadStats: (state, action)=>{
            state.allowReloadStats = action.payload;
        }
    }
});
const { setTotal_users , setActive_users , setTotal_wd , setTotal_paid , setUsers_stats , setAllowReloadStats  } = StatstSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StatstSlice.reducer);


/***/ })

};
;