"use strict";
exports.id = 719;
exports.ids = [719];
exports.modules = {

/***/ 2719:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$M": () => (/* binding */ setIsLogin),
/* harmony export */   "HP": () => (/* binding */ setWarningAllowLogin),
/* harmony export */   "WA": () => (/* binding */ setIsActive),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "fc": () => (/* binding */ setSponsor),
/* harmony export */   "kH": () => (/* binding */ setWallet),
/* harmony export */   "nZ": () => (/* binding */ setIsAdmin),
/* harmony export */   "o4": () => (/* binding */ setToken),
/* harmony export */   "qC": () => (/* binding */ setName),
/* harmony export */   "vV": () => (/* binding */ setEmail),
/* harmony export */   "wt": () => (/* binding */ setLogout),
/* harmony export */   "x$": () => (/* binding */ setUserid)
/* harmony export */ });
/* unused harmony exports AuthSlice, setAuthToken */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    isLogin: false,
    userid: false,
    isActive: false,
    isAdmin: false,
    name: false,
    email: false,
    sponsor: false,
    token: false,
    wallet: false,
    authToken: false,
    warningAllowLogin: true
};
const AuthSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "auth",
    initialState,
    reducers: {
        setIsLogin: (state, action)=>{
            state.isLogin = action.payload;
        },
        setUserid: (state, action)=>{
            state.userid = action.payload;
        },
        setIsActive: (state, action)=>{
            state.isActive = action.payload;
        },
        setIsAdmin: (state, action)=>{
            state.isAdmin = action.payload;
        },
        setName: (state, action)=>{
            state.name = action.payload;
        },
        setEmail: (state, action)=>{
            state.email = action.payload;
        },
        setToken: (state, action)=>{
            state.token = action.payload;
        },
        setSponsor: (state, action)=>{
            state.sponsor = action.payload;
        },
        setWallet: (state, action)=>{
            state.wallet = action.payload;
        },
        setAuthToken: (state, action)=>{
            state.authToken = action.payload;
        },
        setWarningAllowLogin: (state, action)=>{
            state.warningAllowLogin = action.payload;
        },
        setLogout: ()=>initialState
    }
});
const { setLogout , setUserid , setIsLogin , setName , setIsActive , setIsAdmin , setToken , setWallet , setSponsor , setAuthToken , setEmail , setWarningAllowLogin  } = AuthSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AuthSlice.reducer);


/***/ })

};
;