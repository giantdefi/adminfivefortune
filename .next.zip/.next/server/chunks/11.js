"use strict";
exports.id = 11;
exports.ids = [11];
exports.modules = {

/***/ 6603:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BA": () => (/* binding */ setAdmin_wallet),
/* harmony export */   "Jv": () => (/* binding */ setSplittoRwallet),
/* harmony export */   "Lb": () => (/* binding */ setTo_R_Wallet),
/* harmony export */   "MA": () => (/* binding */ setApp_title),
/* harmony export */   "N$": () => (/* binding */ setBonus_sponsor),
/* harmony export */   "N8": () => (/* binding */ setApp_currency),
/* harmony export */   "R6": () => (/* binding */ setLevel_6),
/* harmony export */   "RT": () => (/* binding */ setLevel_10),
/* harmony export */   "Vp": () => (/* binding */ setSplittoEWallet),
/* harmony export */   "X0": () => (/* binding */ setLevel_9),
/* harmony export */   "XS": () => (/* binding */ setApp_tags),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Zu": () => (/* binding */ setLevel_8),
/* harmony export */   "bW": () => (/* binding */ setLevel_2),
/* harmony export */   "cq": () => (/* binding */ setLevel_7),
/* harmony export */   "hL": () => (/* binding */ setLevel_3),
/* harmony export */   "ln": () => (/* binding */ setLevel_1),
/* harmony export */   "mO": () => (/* binding */ setLevel_4),
/* harmony export */   "mX": () => (/* binding */ setApp_description),
/* harmony export */   "pr": () => (/* binding */ setLevel_5),
/* harmony export */   "t5": () => (/* binding */ setTo_E_Wallet),
/* harmony export */   "wS": () => (/* binding */ setApp_domain)
/* harmony export */ });
/* unused harmony export ConstantSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    app_title: false,
    app_domain: false,
    app_description: false,
    app_tags: false,
    app_currency: false,
    admin_wallet: false,
    splittoEWallet: false,
    splittoRwallet: false,
    bonus_sponsor: false,
    //admin send Wallet
    to_E_Wallet: false,
    to_R_Wallet: false,
    // bonus sponsor 
    level_1: false,
    level_2: false,
    level_3: false,
    level_4: false,
    level_5: false,
    level_6: false,
    level_7: false,
    level_8: false,
    level_9: false,
    level_10: false
};
const ConstantSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "constant",
    initialState,
    reducers: {
        setApp_title: (state, action)=>{
            state.app_title = action.payload;
        },
        setApp_domain: (state, action)=>{
            state.app_domain = action.payload;
        },
        setApp_description: (state, action)=>{
            state.app_description = action.payload;
        },
        setApp_tags: (state, action)=>{
            state.app_tags = action.payload;
        },
        setApp_currency: (state, action)=>{
            state.app_currency = action.payload;
        },
        setAdmin_wallet: (state, action)=>{
            state.admin_wallet = action.payload;
        },
        setTo_E_Wallet: (state, action)=>{
            state.to_E_Wallet = action.payload;
        },
        setTo_R_Wallet: (state, action)=>{
            state.to_R_Wallet = action.payload;
        },
        setSplittoEWallet: (state, action)=>{
            state.splittoEWallet = action.payload;
        },
        setSplittoRwallet: (state, action)=>{
            state.splittoRwallet = action.payload;
        },
        setBonus_sponsor: (state, action)=>{
            state.bonus_sponsor = action.payload;
        },
        setLevel_1: (state, action)=>{
            state.level_1 = action.payload;
        },
        setLevel_2: (state, action)=>{
            state.level_2 = action.payload;
        },
        setLevel_3: (state, action)=>{
            state.level_3 = action.payload;
        },
        setLevel_4: (state, action)=>{
            state.level_4 = action.payload;
        },
        setLevel_5: (state, action)=>{
            state.level_5 = action.payload;
        },
        setLevel_6: (state, action)=>{
            state.level_6 = action.payload;
        },
        setLevel_7: (state, action)=>{
            state.level_7 = action.payload;
        },
        setLevel_8: (state, action)=>{
            state.level_8 = action.payload;
        },
        setLevel_9: (state, action)=>{
            state.level_9 = action.payload;
        },
        setLevel_10: (state, action)=>{
            state.level_10 = action.payload;
        }
    }
});
const { setApp_title , setApp_domain , setApp_description , setApp_tags , setApp_currency , setAdmin_wallet , setSplittoEWallet , setSplittoRwallet , setLevel_1 , setLevel_2 , setLevel_3 , setLevel_4 , setLevel_5 , setLevel_6 , setLevel_7 , setLevel_8 , setLevel_9 , setLevel_10 , setTo_E_Wallet , setTo_R_Wallet , setBonus_sponsor  } = ConstantSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ConstantSlice.reducer);


/***/ }),

/***/ 2009:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "n2": () => (/* binding */ resetErrors),
/* harmony export */   "sT": () => (/* binding */ setError)
/* harmony export */ });
/* unused harmony export errorSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    formError: false
};
const errorSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "error",
    initialState,
    reducers: {
        setError: (state, action)=>{
            state.formError = action.payload;
        },
        resetErrors: ()=>initialState
    }
});
const { resetErrors , setError  } = errorSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (errorSlice.reducer);


/***/ })

};
;