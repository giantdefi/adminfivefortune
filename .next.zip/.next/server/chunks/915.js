"use strict";
exports.id = 915;
exports.ids = [915];
exports.modules = {

/***/ 915:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fx": () => (/* binding */ resetForm),
/* harmony export */   "Jq": () => (/* binding */ setCurrentemail),
/* harmony export */   "LE": () => (/* binding */ setCurrentpassword),
/* harmony export */   "Wf": () => (/* binding */ setFormSponsor),
/* harmony export */   "Xc": () => (/* binding */ setToUserID),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "_c": () => (/* binding */ setSendAmount),
/* harmony export */   "cX": () => (/* binding */ setFormPassword),
/* harmony export */   "qI": () => (/* binding */ setNewEmail),
/* harmony export */   "ze": () => (/* binding */ setNewPassword)
/* harmony export */ });
/* unused harmony exports FormSlice, setFormName, setFormUsername, setFormPhone, setFormConfirmPassword, setFormEmail, setConfirmPassword, setCountry, setNewPasswordConfirm, setFirstName, setLastName */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    // registration form
    sponsor: false,
    name: false,
    username: false,
    email: false,
    phone: false,
    password: false,
    confirmPassword: false,
    country: false,
    firstName: false,
    lastName: false,
    //forgot pass
    // WD
    wdWalletAmount: false,
    walletAddr: false,
    //---wd wallet
    depositAmount: false,
    admWalletAddress: false,
    transactionHash: false,
    userWalletAddr: false,
    setSearchUsername: false,
    // change password
    currentpassword: false,
    newPassword: false,
    newPasswordConfirm: false,
    // change email
    currentemail: false,
    newEmail: false,
    // modal send wallet
    toUserID: false,
    SendAmount: false
};
const FormSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "form",
    initialState,
    reducers: {
        setFormSponsor: (state, action)=>{
            state.sponsor = action.payload;
        },
        setFormName: (state, action)=>{
            state.name = action.payload;
        },
        setFormUsername: (state, action)=>{
            state.username = action.payload;
        },
        setFirstName: (state, action)=>{
            state.firstName = action.payload;
        },
        setLastName: (state, action)=>{
            state.lastName = action.payload;
        },
        setFormPhone: (state, action)=>{
            state.phone = action.payload;
        },
        setFormEmail: (state, action)=>{
            state.email = action.payload;
        },
        setCurrentemail: (state, action)=>{
            state.currentemail = action.payload;
        },
        setNewEmail: (state, action)=>{
            state.newEmail = action.payload;
        },
        setFormPassword: (state, action)=>{
            state.password = action.payload;
        },
        setFormConfirmPassword: (state, action)=>{
            state.confirmPassword = action.payload;
        },
        setCountry: (state, action)=>{
            state.country = action.payload;
        },
        // change password
        setCurrentpassword: (state, action)=>{
            state.currentpassword = action.payload;
        },
        setNewPassword: (state, action)=>{
            state.newPassword = action.payload;
        },
        setNewPasswordConfirm: (state, action)=>{
            state.newPasswordConfirm = action.payload;
        },
        // change password
        setCurrentpassword: (state, action)=>{
            state.currentpassword = action.payload;
        },
        setNewPassword: (state, action)=>{
            state.newPassword = action.payload;
        },
        setNewPasswordConfirm: (state, action)=>{
            state.newPasswordConfirm = action.payload;
        },
        setToUserID: (state, action)=>{
            state.toUserID = action.payload;
        },
        setSendAmount: (state, action)=>{
            state.SendAmount = action.payload;
        },
        resetForm: ()=>initialState
    }
});
const { resetForm , setFormSponsor , setFormName , setFormUsername , setFormPhone , setFormPassword , setFormConfirmPassword , setFormEmail , setConfirmPassword , setCountry , setCurrentpassword , setNewPassword , setNewPasswordConfirm , setFirstName , setLastName , setCurrentemail , setNewEmail , setToUserID , setSendAmount  } = FormSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormSlice.reducer);


/***/ })

};
;